from flask import Flask , jsonify , make_response , request , abort, url_for, redirect, render_template
import sqlite3
import os
import time
import ast
import base64
import boto.ses
from random import randint


def random_with_N_digits(n):
    range_start = 10**(n-1)
    range_end = (10**n)-1
    return randint(range_start, range_end)


key = "n3x3K25Cn4BiNEhg3Ahn14CQG0ez8uju"
iv = "3C4549AA4F6B2A6F"


def encode(clear):
    enc = [ ]
    for i in range ( len ( clear ) ):
        key_c = key[ i % len ( key ) ]
        enc_c = chr ( (ord ( clear[ i ] ) + ord ( key_c )) % 256 )
        enc.append ( enc_c )
    return base64.urlsafe_b64encode ( "".join ( enc ).encode ( ) ).decode ( )


def decode(enc):
    dec = [ ]
    enc = base64.urlsafe_b64decode ( enc ).decode ( )
    for i in range ( len ( enc ) ):
        key_c = key[ i % len ( key ) ]
        dec_c = chr ( (256 + ord ( enc[ i ] ) - ord ( key_c )) % 256 )
        dec.append ( dec_c )
    return "".join ( dec )


app = Flask ( __name__ )
cwd = os.getcwd ( )
ts = time.time ( )
ts = int ( ts )


@app.route ( '/login' , methods=[ 'POST' ] )
def login():
    if not request.json or not ('email' in request.json and 'password' in request.json):
        abort ( 400 )
    email = request.json[ 'email' ]
    password = request.json[ 'password' ]
    password = encode ( password )
    token = ''
    if 'token' in request.json:
        token = request.json[ 'token' ]
    parameter_user = [ 'user_id' , 'user_fname' , 'user_lname' , 'email' , 'profile_picpath' ]
    category_list = [ ]
    user_dict = {}
    return_data_dict = {}
    try:
        conn = sqlite3.connect ( "Stevens.db" )
        c = conn.cursor ( )
        query = "SELECT Uid, Ufname, Ulname, Uemail, Uprofpic FROM Users WHERE Uemail='" + email + "' AND Upassword='" + password + "'"
        c.execute ( query )
        data = c.fetchall ( )
        if len ( data ) > 0:
            for i in range ( 0 , len ( data[ 0 ] ) ):
                user_dict[ parameter_user[ i ] ] = data[ 0 ][ i ]
            query = "SELECT * FROM Category"
            c.execute ( query )
            data = c.fetchall ( )
            if len ( data ) > 0:
                for values in data:
                    dict = {'category_id': values[ 0 ] , 'category_name': values[ 1 ]}
                    category_list.append ( dict )
            return_data_dict[ "status code" ] = 200
            return_data_dict[ "message" ] = 'Login successful.'
            return_data_dict[ "user" ] = user_dict
            return_data_dict[ "categories" ] = category_list
        else:
            return_data_dict[ "status code" ] = 400
            return_data_dict[ "message" ] = 'Credentials not correct.'
        conn.close ( )
    except Exception as e:  # sqlite3.OperationalError
        abort ( 400 )
    return_data = ''
    if return_data_dict[ "status code" ] == 200:
        return_data = jsonify ( return_data_dict ) , 200
    else:
        return_data = jsonify ( return_data_dict ) , 400
    return return_data


@app.route ( '/register' , methods=[ 'POST' ] )
def register_user():
    data_json = request.form.to_dict ( )
    dict = ast.literal_eval ( data_json[ 'data' ] )
    keys_list = list ( dict[ 0 ].keys ( ) )
    if 'profile_pic' in keys_list:
        print ( dict[ 0 ][ 'profile_pic' ] )
        return 'recieved'
    if not ('email' in keys_list and 'password' in keys_list and 'first_name' in keys_list and 'last_name' in keys_list):
        abort ( 400 )
    email = dict[ 0 ][ 'email' ]
    password = dict[ 0 ][ 'password' ]
    password = encode ( password )
    first_name = dict[ 0 ][ 'first_name' ]
    last_name = dict[ 0 ][ 'last_name' ]
    # profile_pic_path = ''
    # print('current directory: ', cwd)
    # if 'profile_pic' in keys_list:
    #     image = dict[0]['profile_pic']
    return_data_dict = {}
    try:
        conn = sqlite3.connect ( "Stevens.db" )
        c = conn.cursor ( )
        query = "SELECT Uemail FROM Users WHERE Uemail='" + email + "'"
        c.execute ( query )
        data = c.fetchall ( )
        isUserExists = 'false'
        if len ( data ) > 0:
            return_data_dict[ 'status code' ] = 400
            return_data_dict[ 'message' ] = 'User already exists.'
            isUserExists = 'true'
        if isUserExists != 'true':
            return_data_dict[ 'status code' ] = 200
            return_data_dict[ 'message' ] = 'User registered successfully.'
            try:
                c.execute ( '''INSERT into Users (Ufname, Ulname, Uemail, Upassword) values (?, ?, ?, ?)''' ,
                            (first_name , last_name , email , password) )
                conn.commit ( )
            except sqlite3.ProgrammingError as error:
                print ( error )
        conn.close ( )
    except Exception as e:  # sqlite3.OperationalError
        abort ( 400 )
    return_data = ''
    if return_data_dict[ "status code" ] == 200:
        return_data = jsonify ( return_data_dict ) , 200
    else:
        return_data = jsonify ( return_data_dict ) , 400
    return return_data



# redirect to reset password method
# @app.route('/reset_password', methods=['GET'])
# def open_reset_password():
#     print(request.args.get('ran_num'))
#     try:
#         return render_template('ResetPassword.html', keys = request.args.get('ran_num'))
#     except Exception as error:
#         print('error aa gyi: ',error)
#         abort(400)



@app.route('/forgot_password/reset/<string:random_number>', methods=['GET', 'POST'])
def reset_password(random_number):
    if request.method == 'GET':
        decoded_string = decode(random_number)
        uid = decoded_string.split('-')[0]
        try:
            conn = sqlite3.connect ( "Stevens.db" )
            c = conn.cursor ( )
            query = "SELECT ResetPassword FROM Users WHERE Uid='" + uid + "'"
            c.execute ( query )
            data = c.fetchall ( )
            if len ( data ) > 0:
                if data[0][0] == random_number:
                    return render_template('ResetPassword.html')
                    # return redirect(url_for('open_reset_password', ran_num=random_number))
            else:
                abort(400)
        except Exception as e:
            print("error: ", e)
            abort(400)
    elif request.method == 'POST':
        data_json = request.form.to_dict()
        password = data_json['stevens_live_pwd']
        cnfrm_password = data_json['stevens_live_confirm_pwd']
        if len(password) > 0 and len(cnfrm_password) and password == cnfrm_password:
            print('andar aa gya..')
            conn = sqlite3.connect ( "Stevens.db" )
            c = conn.cursor ( )
            query = "SELECT Uid FROM Users WHERE ResetPassword='" + random_number + "'"
            c.execute ( query )
            data = c.fetchall ( )
            if len ( data ) > 0:
                encoded_number = encode ( password )
                update_query = "UPDATE Users Set ResetPassword=' ', Upassword='" + encoded_number + "' WHERE Uid='" + str (
                    data[ 0 ][ 0 ] ) + "'"
                c.execute ( update_query )
                conn.commit ( )
                return render_template('ResetPassword_success.html')
            else:
                render_template('ResetPassword_error.html')
                abort(404)
        else:
            return render_template ( 'ResetPassword.html' )
    return ''


@app.route ( '/forgot_password', methods=['POST'] )
def forgot_password():
    if not request.json or not ('email' in request.json):
        abort(400)
    email = request.json['email']
    return_data_dict = {}
    try:
        conn = sqlite3.connect ( "Stevens.db" )
        c = conn.cursor ( )
        query = "SELECT Uemail, Uid FROM Users WHERE Uemail='" + email + "'"
        c.execute ( query )
        data = c.fetchall ( )
        isUserExists = 'false'
        if len ( data ) > 0:
            number = data[0][1]
            random_number = random_with_N_digits ( 6 )
            number = str(number) + '-' + str(random_number)
            url = request.url
            encoded_number = encode(number)
            url = url + "/reset/" + encoded_number
            update_query = "UPDATE Users Set ResetPassword='" + encoded_number + "' WHERE Uid='" + str(data[0][1]) + "'"
            c.execute(update_query)
            conn.commit ( )
            message = "Click below link to reset your password.\n\n\n" + url
            connection = boto.ses.connect_to_region('us-west-2', aws_access_key_id='AKIAJN4MYUQTGOXF2TTA',
                                                    aws_secret_access_key='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')
            connection.send_email ('akshya672222@gmail.com' , 'Reset Password' , message ,[ email ] )
            return_data_dict[ 'status code' ] = 200
            return_data_dict[ 'message' ] = 'Email sent. Please check your registered email for reset password instructions.'
            isUserExists = 'true'
        if isUserExists != 'true':
            return_data_dict[ 'status code' ] = 400
            return_data_dict[ 'message' ] = 'Email address is not registered.'
        conn.close ( )
    except Exception as e:  # sqlite3.OperationalError
        print('come here..', e)
        abort(400)
    return jsonify ( return_data_dict )


@app.route ( '/event_list/<int:page_number>' )
def fetch_event_list(page_number):
    diff = 20
    start_index = ((0+diff) * (page_number - 1))
    end_index = ((0+diff) * (page_number)) - 1
    return_data_dict = {}
    event_details_list = ['EventId', "Event_name", "Event_location", "Event_time", "Event_date", "Event_description", "Event_category"]
    event_list = []
    try:
        conn = sqlite3.connect ( "Stevens.db" )
        c = conn.cursor ( )
        query = "SELECT Eid, Ename, Elocation, Etime, Edate, Edescription FROM Events LIMIT " + str(start_index) + ", " + str(diff)
        c.execute (query)
        data = c.fetchall()
        if len(data) >0:
            for events in data:
                dict = {}
                for i in range ( 0 , len ( event_details_list ) ):
                    if i < len(event_details_list) - 1:
                        dict[event_details_list[i]] = events[i]
                    elif i == len(event_details_list) - 1:
                        query = "SELECT Cid from EventCategory WHERE Eid='" + events[0] + "'"
                        c.execute ( query )
                        category_data = c.fetchall()
                        cid_list = []
                        if len(category_data) > 0:
                            for cid in category_data:
                                cid_list.append(cid[0])
                        dict[event_details_list[i]] = cid_list
                event_list.append(dict)
        else:
            abort(404)
    except Exception as e:  # sqlite3.OperationalError
        abort(400)
    return_data_dict[ 'message' ] = 'Hello from Evil Akshay!!!'
    return_data_dict['events_list'] = event_list
    return_data_dict[ 'status code' ] = 200
    return_data_dict['page_number'] = page_number
    return jsonify ( return_data_dict )


@app.route ( '/hello' )
def hello():
    return 'Hello from Evil Akshay!!!'


# error handler codes
@app.errorhandler ( 400 )
def not_found(error):
    return make_response ( jsonify ( {'error': 'Invalid request.'} ) , 400 )


@app.errorhandler ( 405 )
def not_found(error):
    return make_response ( jsonify ( {'error': 'Bad request.'} ) , 405 )


@app.errorhandler ( 404 )
def not_found(error):
    return make_response ( jsonify ( {'error': 'Not found.'} ) , 404 )


if __name__ == '__main__':
    app.run ( debug=True )
