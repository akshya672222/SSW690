try:
    import urllib.request as urllib2
except ImportError:
    import urllib2
import io
import  re
import sys
from bs4 import BeautifulSoup
import sqlite3
from selenium import webdriver

def open_page(url):
    # browser = webdriver.Chrome('/Users/AKSHAY/Downloads/chromedriver')
    browser = webdriver.PhantomJS('/Users/AKSHAY/Downloads/phantomjs-2.1.1-macosx/bin/phantomjs')
    browser.get(url)
    html = browser.page_source
    soup = BeautifulSoup ( html , 'html.parser' )
    event = soup.find("div", attrs={"class":"field field-name-body field-type-text-with-summary field-label-hidden"})
    browser.quit()
    return event


def fitch_event(Event):
    Event_List = []
    D_L= "https://www.stevens.edu"
    
    for e in Event:
        temp=[]
        
        # get all events under this date
        event =e.find_all("article",attrs={"class" : "clearfix events_list_wide_item"})
        
        for ev in event:
            # get date
            Date = e.find("h2",attrs={"class" : "events_list_day_date"})
            d=(Date.get_text()).encode('ascii', 'ignore')
            temp += [d]

            # get title
            title= ev.find("h3",attrs={"class" : "events_list_wide_item_title"})
            title2 = ev.find("h3",attrs={"class" : "events_list_wide_item_title"})['id']
            ti=(title.get_text()).encode('ascii', 'ignore')
            temp+=[title2.split('-')[-1]]
            temp+=[ti]

            # get location
            Location=ev.find("div",attrs={"class" : "fs-cell fs-md-2 fs-lg-4 events_list_wide_item_locations"})
            if len(Location) < 5:
                temp+=["NA"]
            else:
                m=ev.find("div",attrs={"class" : "events_list_wide_item_location_data"})
                loc=(m.get_text()).encode('ascii', 'ignore')
                temp+=[loc]
            
            # get time
            time = ev.find("time",attrs={"class" : "events_list_wide_item_time"})
            t=(time.get_text()).encode('ascii', 'ignore')
            temp+=[t]

            # get description
            
            """
            links=event.find("a",attrs={"class" :"events_list_wide_item_button events_list_wide_item_button_detail"})
            l= links.get('href')
            desclink= D_L + l
            link= urllib2.Request(desclink,headers={'User-Agent': 'Safari/537.36'})
            h = urllib2.urlopen(link).read().decode('utf8')
            s = BeautifulSoup(h, 'html.parser')
            desc =s.find("div",attrs={"class" : "field-item even"})
            m=(desc.get_text()).encode('ascii', 'ignore')
            print m
            d=(desc.get_text()).encode('ascii', 'ignore')
            temp+=[d]
            """
            # get category
            category = ev.find("span",attrs={"class" : "events_list_wide_item_cat"})
            c=(category.get_text()).encode('ascii', 'ignore')
            if len(c)>0:
                temp+=[c]
            else:
                temp+=["NA"]

            # print(temp)

            Event_List=Event_List+[temp]

    
    # for r in Event_List:
    #     print (r)
    return Event_List

def fill_db(Event_Data,cur,con):
    for r in Event_Data:
        cur.execute("INSERT INTO Events (Ename, Elocation, Etime, Edate) VALUES (?,?,?,?)",(r[1],r[2],r[3],r[0]))
        con.commit()
    print ("MAHA")


try:
    con = sqlite3.connect("Stevens.db")
    cur=con.cursor()
    
except Exception as e: #sqlite3.OperationalError
    print (e)

inputURL = "https://www.stevens.edu/events"

url= urllib2.Request(inputURL,headers={'User-Agent': 'Safari/537.36'})

html = urllib2.urlopen(url).read().decode('utf8')
soup = BeautifulSoup(html, 'html.parser')

E =soup.find_all("div",attrs={"class" : "events_list_wide_day"})

Event_Data= fitch_event(E)
# print (len(Event_Data))

open_page('https://www.stevens.edu/events/njwa-nyswa-cooperative-career-fair-educational-event')

# fill_db(Event_Data,cur,con)
    
    

