import datetime
 
with open('outputDate.txt','a') as outFile:
    outFile.write('\n' + str(datetime.datetime.now()))

    