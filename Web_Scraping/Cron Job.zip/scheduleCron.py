from crontab import CronTab

my_cron = CronTab(user='username')

job = my_cron.new(command='python writeDate.py')
job.hour.every(1)

my_cron.write()
